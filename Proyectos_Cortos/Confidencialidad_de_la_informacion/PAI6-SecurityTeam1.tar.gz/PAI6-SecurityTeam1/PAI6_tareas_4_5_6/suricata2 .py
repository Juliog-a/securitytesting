from collections import defaultdict
from datetime import datetime

archivo_registro = "/home/raquel/logs/fast.log"  # reg logs de suricata
archivo_informe = "informe_mensual.log"  # Ruta del archivo de informe


alertas_por_servicio = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))

with open(archivo_registro, "r") as archivo:
    lineas = archivo.readlines()

    for linea in lineas:
        elementos = []
        indice_inicio = 0
        for i, char in enumerate(linea):
            if char == '[' or char == ']': #por el formato del logs, es la forma más rápida de clasificar la informacion
                elementos.append(linea[indice_inicio:i].strip())
                indice_inicio = i + 1
        elementos.append(linea[indice_inicio:].strip())
        elementos = [elem for elem in elementos if elem]
        fecha_str = elementos[0] 
        fecha = datetime.strptime(fecha_str, "%m/%d/%Y-%H:%M:%S.%f")
        servicio = elementos[3]
        clasificacion = elementos[5]
        alertas_por_servicio[servicio][clasificacion][fecha.strftime("%b %Y")] += 1

    # INFORME
with open(archivo_informe, "w") as archivo_salida:
    for servicio, clasificaciones in alertas_por_servicio.items():
        archivo_salida.write(f"Informe Mensual para el Servicio {servicio}:\n")
        for clasificacion, alertas_mensuales in clasificaciones.items():
            archivo_salida.write(f"  Clasificación: {clasificacion}\n")
            for mes, cantidad_alertas in alertas_mensuales.items():
                archivo_salida.write(f"    {mes}: {cantidad_alertas} alertas\n")
            archivo_salida.write("\n")
